<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jan_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 466
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: feb_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 467
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: mar_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 468
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: apr_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 469
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: may_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 470
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jun_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 471
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jul_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 472
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: aug_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 473
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: sep_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 474
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: oct_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 475
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: nov_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 476
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: dec_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 477
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jan_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 490
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: feb_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 491
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: mar_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 492
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: apr_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 493
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: may_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 494
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jun_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 495
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jul_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 496
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: aug_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 497
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: sep_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 498
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: oct_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 499
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: nov_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 500
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: dec_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 501
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jan_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 515
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: feb_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 516
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: mar_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 517
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: apr_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 518
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: may_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 519
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jun_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 520
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: jul_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 521
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: aug_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 522
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: sep_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 523
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: oct_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 524
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: nov_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 525
ERROR - 2020-01-31 21:37:46 --> Severity: Notice  --> Undefined variable: dec_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 526
ERROR - 2020-01-31 21:37:48 --> Severity: 8192  --> The each() function is deprecated. This message will be suppressed on further calls C:\laragon_2\www\nutrifux\multiclinica\application\third_party\MX\Modules.php 82
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jan_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 466
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: feb_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 467
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: mar_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 468
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: apr_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 469
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: may_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 470
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jun_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 471
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jul_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 472
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: aug_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 473
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: sep_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 474
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: oct_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 475
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: nov_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 476
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: dec_total2 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 477
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jan_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 490
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: feb_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 491
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: mar_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 492
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: apr_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 493
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: may_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 494
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jun_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 495
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jul_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 496
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: aug_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 497
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: sep_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 498
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: oct_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 499
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: nov_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 500
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: dec_total1 C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 501
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jan_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 515
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: feb_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 516
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: mar_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 517
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: apr_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 518
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: may_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 519
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jun_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 520
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: jul_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 521
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: aug_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 522
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: sep_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 523
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: oct_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 524
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: nov_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 525
ERROR - 2020-01-31 21:38:10 --> Severity: Notice  --> Undefined variable: dec_total C:\laragon_2\www\nutrifux\multiclinica\application\modules\home\views\home.php 526
ERROR - 2020-01-31 21:38:12 --> Severity: 8192  --> The each() function is deprecated. This message will be suppressed on further calls C:\laragon_2\www\nutrifux\multiclinica\application\third_party\MX\Modules.php 82
ERROR - 2020-01-31 21:38:18 --> Severity: 8192  --> The each() function is deprecated. This message will be suppressed on further calls C:\laragon_2\www\nutrifux\multiclinica\application\third_party\MX\Modules.php 82
ERROR - 2020-01-31 21:38:34 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:38:34 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:38:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:38:56 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:38:56 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:38:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:39:16 --> Could not find the language line "expire_date"
ERROR - 2020-01-31 21:39:43 --> Severity: Notice  --> Trying to get property 'name' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:39:43 --> Severity: Notice  --> Trying to get property 'address' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:39:43 --> Severity: Notice  --> Trying to get property 'phone' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:39:49 --> Severity: 8192  --> The each() function is deprecated. This message will be suppressed on further calls C:\laragon_2\www\nutrifux\multiclinica\application\third_party\MX\Modules.php 82
ERROR - 2020-01-31 21:40:04 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:40:04 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:40:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:40:09 --> Could not find the language line "doctors_commission"
ERROR - 2020-01-31 21:40:27 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:40:27 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:40:27 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:42:08 --> Severity: Notice  --> Trying to get property 'name' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:42:08 --> Severity: Notice  --> Trying to get property 'address' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:42:08 --> Severity: Notice  --> Trying to get property 'phone' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:42:19 --> Severity: Notice  --> Trying to get property 'name' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:42:19 --> Severity: Notice  --> Trying to get property 'address' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:42:19 --> Severity: Notice  --> Trying to get property 'phone' of non-object C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\controllers\patient.php 892
ERROR - 2020-01-31 21:42:31 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\views\patient_payments.php 211
ERROR - 2020-01-31 21:42:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\views\patient_payments.php 211
ERROR - 2020-01-31 21:42:50 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:42:50 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:42:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:43:03 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:43:03 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:43:03 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:43:09 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:43:09 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:43:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:43:13 --> Could not find the language line "doctors_commission"
ERROR - 2020-01-31 21:43:16 --> Could not find the language line "doctors_commission"
ERROR - 2020-01-31 21:43:36 --> Could not find the language line "doctors_commission"
ERROR - 2020-01-31 21:43:40 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:43:40 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:43:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:48:04 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:48:04 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:48:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:48:51 --> Could not find the language line "refd_by_doctor"
ERROR - 2020-01-31 21:48:51 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:48:51 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\views\add_payment_view.php 194
ERROR - 2020-01-31 21:49:01 --> 404 Page Not Found --> common/assets/DataTables/pdfmake.min.js.map
ERROR - 2020-01-31 21:51:52 --> 404 Page Not Found --> common/assets/DataTables/pdfmake.min.js.map
ERROR - 2020-01-31 22:12:48 --> 404 Page Not Found --> common/assets/DataTables/pdfmake.min.js.map
ERROR - 2020-01-31 22:12:56 --> Could not find the language line "doctors_commission"
ERROR - 2020-01-31 22:12:58 --> 404 Page Not Found --> common/assets/DataTables/pdfmake.min.js.map
ERROR - 2020-01-31 22:17:25 --> Severity: Notice  --> Undefined property: stdClass::$esteticista C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\controllers\finance.php 1409
ERROR - 2020-01-31 22:17:25 --> Severity: Notice  --> Undefined property: stdClass::$esteticista_name C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\controllers\finance.php 1417
ERROR - 2020-01-31 22:17:25 --> Severity: Notice  --> Undefined property: stdClass::$esteticista C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\controllers\finance.php 1409
ERROR - 2020-01-31 22:17:25 --> Severity: Notice  --> Undefined property: stdClass::$esteticista_name C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\controllers\finance.php 1417
ERROR - 2020-01-31 22:19:47 --> Severity: Notice  --> Undefined property: stdClass::$esteticista_name C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\controllers\finance.php 1417
ERROR - 2020-01-31 22:19:47 --> Severity: Notice  --> Undefined property: stdClass::$esteticista_name C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\controllers\finance.php 1417
ERROR - 2020-01-31 22:19:50 --> Severity: Notice  --> Undefined property: stdClass::$esteticista_name C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\controllers\finance.php 1417
ERROR - 2020-01-31 22:19:50 --> Severity: Notice  --> Undefined property: stdClass::$esteticista_name C:\laragon_2\www\nutrifux\multiclinica\application\modules\finance\controllers\finance.php 1417
ERROR - 2020-01-31 22:21:06 --> Could not find the language line "doctors_commission"
ERROR - 2020-01-31 22:21:15 --> Severity: Notice  --> Undefined variable: doctors C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\views\patient_payments.php 211
ERROR - 2020-01-31 22:21:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\laragon_2\www\nutrifux\multiclinica\application\modules\patient\views\patient_payments.php 211
ERROR - 2020-01-31 22:22:00 --> Could not find the language line "doctors_commission"
ERROR - 2020-01-31 22:22:13 --> Could not find the language line "doctors_commission"
ERROR - 2020-01-31 22:22:36 --> Severity: 8192  --> The each() function is deprecated. This message will be suppressed on further calls C:\laragon_2\www\nutrifux\multiclinica\application\third_party\MX\Modules.php 82
